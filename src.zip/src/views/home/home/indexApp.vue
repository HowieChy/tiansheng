<template>
<div id="app">
	<!--公用头部组件-->
	<McHead @child-number="get"   @child-price="get2"  @child-cutTime="get3" :lists="carItems" :allPrice="allPrice" :allNum="allNum"  :cutTime="cutTime">
		<div class="m-search" slot='u-search'>
			<input type="text" value="" placeholder="牛肉">
			<i class="el-icon-search"></i>
		</div>
	</McHead>

	<!--导航-->
	<div class="g-nav">
		<div class="content">
			<div class="m-all">
				<ul>
					<li>
						<p>全部分类</p>
					</li>
					<li @mouseenter="jNav1" @mouseleave="jNav2">
						<p><span>天生好菜</span></p>
						<div class="m-float">
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a>
							</div>
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a>
							</div>
						</div>
					</li>
					<li @mouseenter="jNav1" @mouseleave="jNav2">
						<p><span>天滋美肉</span></p>
						<div class="m-float">
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a>
							</div>
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a>
							</div>
						</div>
					</li>
					<li @mouseenter="jNav1" @mouseleave="jNav2">
						<p><span>天天有鱼</span></p>
						<div class="m-float">
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a>
							</div>
						</div>
					</li>
					<li @mouseenter="jNav1" @mouseleave="jNav2">
						<p><span>原生好蛋</span></p>
						<div class="m-float">
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a>
							</div>
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a>
							</div>
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a>
							</div>
						</div>
					</li>
					<li @mouseenter="jNav1" @mouseleave="jNav2">
						<p><span>天赐好粮</span></p>
						<div class="m-float">
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a>
							</div>
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a>
							</div>
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a>
							</div>
						</div>
					</li>
					<li @mouseenter="jNav1" @mouseleave="jNav2">
						<p><span>果色天香</span></p>
						<div class="m-float">
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a>
							</div>
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a>
							</div>
						</div>

					</li>
					<li @mouseenter="jNav1" @mouseleave="jNav2">
						<p><span>天生丽制</span></p>
						<div class="m-float">
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a>
							</div>
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a>
							</div>
						</div>
					</li>
					<li @mouseenter="jNav1" @mouseleave="jNav2">
						<p><span>天生丽制</span></p>
						<div class="m-float">
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a><a href="">新西兰柠檬</a><a href="">青菜</a><a href="">萝卜</a>
							</div>
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a>
							</div>
							<div class="item">
								<h2>蔬菜 <i class="el-icon-arrow-right"></i></h2>
								<a href="">青菜</a><a href="">萝卜</a><a href="">西瓜</a>
							</div>
						</div>
					</li>
				</ul>
			</div>
			<div class="m-nav">
				<a href="">闪送专区</a>
				<a href="">VIP专区</a>
				<a href="">免耕专区</a>
				<a href="">宅配套餐</a>
				<a href="">卡卷专区</a>
				<a href="">产品超市</a>
				<a href="">农场活动</a>
				<a href="">农场日志</a>
			</div>
		</div>
	</div>
	<!--/导航-->

	<!--轮播图-->
	<div class="g-Carousel">
		<el-carousel trigger="click" :interval="5000">
			<el-carousel-item v-for="(item,index) in slide" :key="index" :label="item.title">
				<a :href="item.aHref">
					<img src="http://img2.niutuku.com/desk/1207/1025/ntk124744.jpg" alt="">
				</a>
			</el-carousel-item>
		</el-carousel>
	</div>
	<!--/轮播图-->



	<div class="g-listed">
		<h2>上市货</h2>

		<!--商品-->
		<ul class="m-shop clearfix">
			<li v-for="(item,index) in shopItem">
				<a href=""><img :src="item.aImg" alt=""></a>
				<p>{{item.title}}</p>
				<p>库存:{{item.store}}</p>
				<p>会员价：<em>￥{{item.newPrice}}</em></p>
				<p>市场价：￥{{item.oldPrice}}</p>
				<div v-if="index==0||index==3||index==4">
					<!--计数-->
					<el-input-number size="small" v-model="item.numer" :min="1" :max="item.store"></el-input-number>
					<!--购物图标-->
					<ins :id="item.id" @click="addShop" :num="item.numer" :price="item.newPrice"></ins>
				</div>

				<button  class="u-button" v-if="index==1">已售罄</button>

				<button  class="u-button u-time" v-if="index==2"><em>离开始还有 <count-down :endTime="item.time" :callback="callback" endText="0S"></count-down></em></button>

			</li>
		</ul>

	</div>

	<div class="g-content">

		<!--VIP专区-->
		<div class="g-shops">
			<h2>VIP专区</h2>
			<a class="u-ad" href="">
				<img src="./assets/images/ad.png" alt="">
			</a>
			<!--商品-->
			<ul class="m-shop clearfix">
				<li v-for="(item,index) in shopItem">
					<a href=""><img :src="item.aImg" alt=""></a>
					<p>{{item.title}}</p>
					<p>库存:{{item.store}}</p>
					<p>会员价：<em>￥{{item.newPrice}}</em></p>
					<p>市场价：￥{{item.oldPrice}}</p>
					<div v-if="index==0||index==3||index==4">
						<!--计数-->
						<el-input-number size="small" v-model="item.numer" :min="1" :max="item.store"></el-input-number>
						<!--购物图标-->
						<ins :id="item.id" @click="addShop" :num="item.numer" :price="item.newPrice"></ins>
					</div>

					<button  class="u-button" v-if="index==1">已售罄</button>

					<button  class="u-button u-time" v-if="index==2"><em>离开始还有 <count-down :endTime="item.time" :callback="callback" endText="0S"></count-down></em></button>

				</li>
			</ul>
		</div>

		<div class="g-shops">
			<h2 class="u-new">今日上新</h2>
			<a class="u-ad" href="">
				<img src="./assets/images/ad.png" alt="">
			</a>
			<!--商品-->
			<ul class="m-shop clearfix">
				<li v-for="(item,index) in shopItem" id="aaa">
					<a href=""><img :src="item.aImg" alt=""></a>
					<p>{{item.title}}</p>
					<p>库存:{{item.store}}</p>
					<p>会员价：<em>￥{{item.newPrice}}</em></p>
					<p>市场价：￥{{item.oldPrice}}</p>
					<div v-if="index==0||index==3||index==4">
						<!--计数-->
						<el-input-number size="small" v-model="item.numer" :min="1" :max="item.store"></el-input-number>
						<!--购物图标-->
						<ins :id="item.id" @click="addShop" :num="item.numer" :price="item.newPrice"></ins>
					</div>

					<button  class="u-button" v-if="index==1">已售罄</button>

					<button  class="u-button u-time" v-if="index==2"><em>离开始还有 <count-down :endTime="item.time" :callback="callback" endText="0S"></count-down></em></button>

				</li>
			</ul>
		</div>
		
		
		<!--产品检测-->
		<div class="g-items">
			<h2 class="u-jc">产品检测</h2>
			<a href="">
				<img src="./assets/images/jc1.png" alt="">
			</a>
			<a href="">
				<img src="./assets/images/jc2.png" alt="">
			</a>
			<a href="">
				<img src="./assets/images/jc3.png" alt="">
			</a>
		</div>

		<!--农场风采-->
		<div class="g-items">
			<h2>农场风采</h2>
			<a href="">
				<img src="./assets/images/pic.png" alt="">
				<div class="m-mask"></div>
			</a>
			<a href="">
				<img src="./assets/images/pic.png" alt="">
				<div class="m-mask"></div>
			</a>
			<a href="">
				<img src="./assets/images/pic.png" alt="">
				<div class="m-mask"></div>
			</a>
		</div>
	</div>



	<!--公用底部组件-->
	<McFoot></McFoot>
</div>
</template>

<script>

import Lib from 'assets/js/Lib';
/*头部组件*/
import McHead from 'components/McHead';
/*底部组件*/
import McFoot from 'components/McFoot';
/*倒计时组件*/
import countDown from 'components/Countdown';

/*商品图*/
import aImg from './assets/images/shop.png'

import $ from 'jquery'

import imagezoom from './assets/jquery.imagezoom.min.js'

export default {
  data() {
    return {

        //轮播图
        slide:[{
            "img":"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=150362903&di=6ad534cda71f5eb24bc2753fc2dfa3ec&imgtype=jpg&er=1&src=http%3A%2F%2Fimage5.tuku.cn%2Fpic%2Fwallpaper%2Fyouxidongman%2Fqianweishaonvdongmanbizhi%2F011.jpg",
			"aHref":"",
			"title":"冰鲜汤排"
		},{
            "img":"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1503629603&di=6ad534cda71f5eb24bc2753fc2dfa3ec&imgtype=jpg&er=1&src=http%3A%2F%2Fimage5.tuku.cn%2Fpic%2Fwallpaper%2Fyouxidongman%2Fqianweishaonvdongmanbizhi%2F011.jpg",
            "aHref":"",
            "title":"冰鲜汤排"
        },{
            "img":"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1503629603&di=6ad534cda71f5eb24bc2753fc2dfa3ec&imgtype=jpg&er=1&src=http%3A%2F%2Fimage5.tuku.cn%2Fpic%2Fwallpaper%2Fyouxidongman%2Fqianweishaonvdongmanbizhi%2F011.jpg",
            "aHref":"",
            "title":"冰鲜汤排"
        },{
            "img":"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1503629603&di=6ad534cda71f5eb24bc2753fc2dfa3ec&imgtype=jpg&er=1&src=http%3A%2F%2Fimage5.tuku.cn%2Fpic%2Fwallpaper%2Fyouxidongman%2Fqianweishaonvdongmanbizhi%2F011.jpg",
            "aHref":"",
            "title":"冰鲜汤排"
        },{
            "img":"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1503629603&di=6ad534cda71f5eb24bc2753fc2dfa3ec&imgtype=jpg&er=1&src=http%3A%2F%2Fimage5.tuku.cn%2Fpic%2Fwallpaper%2Fyouxidongman%2Fqianweishaonvdongmanbizhi%2F011.jpg",
            "aHref":"",
            "title":"冰鲜汤排"
        }],

        //商品列表
        shopItem:[{
            	title:"四川凯特芒果",
            	store:10,
				newPrice:'300.00',
				oldPrice:'400.00',
				id:'1',
            	numer: 1,
				aImg:aImg,
				time:"1504796400",
			},
            {
                title:"四川凯特芒果",
                store:5,
                newPrice:'200.50',
                oldPrice:'300.00',
                id:'5',
                numer: 1,
                aImg:aImg,
                time:"1504796400",
            },
            {
                title:"四川凯特芒果",
                store:2,
                newPrice:'700.00',
                oldPrice:'900.00',
                id:'2',
                numer: 1,
                aImg:aImg,
                time:"1504796400",
            },
            {
                title:"四川凯特芒果",
                store:200,
                newPrice:'500.05',
                oldPrice:'600.00',
                id:'7',
                numer: 1,
                aImg:aImg,
                time:"1504796400",
            },
            {
                title:"四川凯特芒果",
                store:200,
                newPrice:'500.05',
                oldPrice:'600.00',
                id:'7',
                numer: 1,
                aImg:aImg,
                time:"1504796400",
            }],


        //购物车列表
        carItems:[{
            price:'300.00',
			num:1,
			id:'1'
		},
            {
                price:'300.00',
                num:1,
                id:'2'
            }],

        allPrice:'600.00',//商品总价
		allNum:2,//商品总数

		//倒计时
		cutTime:'1504796400'
    }
  },
    components: {
        McHead,McFoot,countDown
    },
  //实例初始化最之前，无法获取到data里的数据
  beforeCreate(){
  	
  	
  },  
  //在挂载开始之前被调用
  beforeMount(){
  	
  
  }, 
  //已成功挂载，相当ready()
  mounted(){

  },
  //相关操作事件
  methods: {

      get(msg){
          this.allNum=msg
      },
      get2(msg){
          this.allPrice=msg
      },
      get3(msg){
          this.cutTime='0'
      },

	  //导航
      jNav1(e){
          $('.m-float').hide();
          $(e.currentTarget).find('.m-float').show()
	  },
      jNav2(e){
          $('.m-float').hide();
      },

	  //开始倒计时
      callback(){
		console.log('结束')
      },
	  //购买商品
      addShop(e){
	      if( $(e.currentTarget).attr('rel')=='1'){
	          alert('库存为0,不能继续购买');
	          return false
		  }
	      var zIndex=$(e.currentTarget).parents('li').index();
          this.shopItem[zIndex].store=this.shopItem[zIndex].store-this.shopItem[zIndex].numer;
          if(this.shopItem[zIndex].store<0){
              this.shopItem[zIndex].store=0;
              $(e.currentTarget).attr('rel','1')
		  }
          this.shopItem[zIndex].numer=1;
			if(!this.carItems.length){
                console.log('第一次添加')
                this.carItems.push({
                    price:$(e.currentTarget).attr('price'),
                    num:$(e.currentTarget).attr('num'),
                    id:$(e.currentTarget).attr('id')
                });

                this.cutTime=(parseInt(new Date().getTime()/1000)+1802).toString();

                this.allNum=0;
                this.allPrice=0;
                this.carItems.map(function (item) {
                    this.allNum=this.allNum+parseInt(item.num);
                    this.allPrice+=item.price*item.num
                }.bind(this))
				return false
            }
		  for(var i=0;i<this.carItems.length;i++){

              if($(e.currentTarget).attr('id')==this.carItems[i].id){
                  console.log('已重复添加')
                  this.carItems[i].num=parseInt(this.carItems[i].num)+parseInt($(e.currentTarget).attr('num'));


                  this.allNum=0;
                  this.allPrice=0;
                  this.carItems.map(function (item) {
                      this.allNum=this.allNum+parseInt(item.num);
                      this.allPrice+=item.price*item.num
                  }.bind(this))
                  return false
              };
              if(i==this.carItems.length-1){
                  console.log('新添加')
				  this.carItems.push({
					  price:$(e.currentTarget).attr('price'),
					  num:$(e.currentTarget).attr('num'),
					  id:$(e.currentTarget).attr('id')
              		}
          		);

                  this.allNum=0;
                  this.allPrice=0;
                  this.carItems.map(function (item) {
                      this.allNum=this.allNum+parseInt(item.num);
                      this.allPrice+=item.price*item.num
                  }.bind(this))
                  return false
			  }
		  }

	  },


      
  }
}
</script>

<style lang="less">

	/*导航*/
	.g-nav{
		width:100%;
		background: #30b947;
		height: 40px;
		line-height: 40px;
		.content{
			width: 960px;
			margin: 0 auto;
			padding-left: 240px;
			position: relative;
			a{
				color: #fff;
				display: inline-block;
				padding: 0 30.5px;
			}
			a:hover{
				background: url("./assets/images/bg3.png");
			}
		}
		/*分类*/
		.m-all{
			position: absolute;
			left: 0;
			top: 0;
			background: url("./assets/images/bg3.png");
			z-index: 999;
			width: 240px;

			p:hover{
				background: url("./assets/images/bg2.png");
				cursor: pointer;
			};
			span{
				display: inline-block;
				text-indent: 0;
				line-height: normal;
				width: 240px;
				height: 47px;
				line-height: 47px;
				text-indent: 74px;
			}
			li{
				color: #fff;
			}
			li:first-child{
				height: 40px;
				line-height: 40px;
				text-indent: 74px;
				background: #2ba63e;
				p{
					background: url("./assets/images/p1.png") no-repeat 30px 50%;
				}
			}
			li:nth-of-type(2){
				margin-top: 14px;
				span{
					background: url("./assets/images/p2.png") no-repeat 30px 50%;
				}
			}
			li:nth-of-type(3){
				span{
					background: url("./assets/images/p3.png") no-repeat 30px 50%;
				}
			}
			li:nth-of-type(4){
				span{
					background: url("./assets/images/p4.png") no-repeat 30px 50%;
				}
			}
			li:nth-of-type(5){
				span{
					background: url("./assets/images/p5.png") no-repeat 30px 50%;
				}
			}
			li:nth-of-type(6){
				span{
					background: url("./assets/images/p6.png") no-repeat 30px 50%;
				}
			}
			li:nth-of-type(7){
				span{
					background: url("./assets/images/p7.png") no-repeat 30px 50%;
				}
			}
			li:nth-of-type(8){
				span{
					background: url("./assets/images/p8.png") no-repeat 30px 50%;
				}
			}
			li:last-of-type{
				margin-bottom: 14px;
				span{
					background: url("./assets/images/p9.png") no-repeat 30px 50%;
				}
			}
			/*悬浮分类*/
			.m-float{
				display: none;
				width: 770px;
				min-height: 354px;
				background: #fff;
				position: absolute;
				top: 40px;
				left: 240px;
				line-height: normal;
				color: #000;
				text-indent: 0;
				box-shadow: 0 3px 5px #ccc;
				padding: 25px 40px ;
				.item{
					margin-bottom: 30px;
					i{
						margin-left: 12px;
						font-size: 18px;
					}
				}
				a{
					color: #666;
					display: inline-block;
					padding-left: 0;
					padding-right: 50px;
					margin-bottom: 20px;
				}
				a:hover{
					color: #2ba63e;
					background: #fff;
				}
				h2{
					font-size: 20px;
					margin-bottom: 20px;
				}

			}


		}
	}

	/*轮播图*/
	.g-Carousel{
		height: 404px;
		width: 1200px;
		margin: 0 auto;
		img{
			width: 1200px;
			height: 100%;
		}
		.el-carousel__indicators--labels{
			padding-left: 230px;
		}
		.el-carousel__button{
			background: url("./assets/images/bg1.png") no-repeat;
			opacity: 1;
		}
		.el-carousel__indicators--labels .el-carousel__button{
			width: 183px;
			height: 40px;
		}
		.el-carousel__indicators--labels .el-carousel__indicator{
			padding: 6px 2px;
		}
		.el-carousel__indicator.is-active button{
			background: url("./assets/images/bg2.png") no-repeat;
			color: #fff;
		}
		.el-carousel__container{
			height: 404px;
		}
		.el-carousel__arrow--left{
			left: 256px;
		}
		.el-carousel__arrow--right{
			right: 16px;
		}
	}

	.g-content{
		background: #f4f4f4;
		margin-top: 30px;
		padding-bottom: 10px;
	}
	/*农场风采*/
	.g-items{
		width: 1200px;
		margin: 0 auto;
		padding: 10px 0 ;
		font-size: 0;
		a{
			width: 386px;
			height: 380px;
			display: inline-block;
			margin-right: 20px;
			position: relative;
		}
		img{
			width: 100%;
			height: 100%;
		}
		a:last-child{
			margin: 0;
		}
		h2{
			font-size: 20px;
			padding:  20px 0;
			background: url("./assets/images/item1.png") no-repeat 4px 50%;
			padding-left: 46px;
			font-weight: bold;
		}
		.u-jc{
			background: url("./assets/images/item2.png") no-repeat 4px 50%;
		}
		.m-mask{
			width: 386px;
			height: 380px;
			position: absolute;
			left: 0;
			top: 0;
			background: url("./assets/images/mask.png") no-repeat 50% 50%;
		}
	}

	/*上市货*/
	.g-listed{
		width: 1200px;
		margin: 0 auto;
		h2{
			font-size: 20px;
			padding:  20px 0;
			background: url("./assets/images/item0.png") no-repeat 4px 50%;
			padding-left: 46px;
			font-weight: bold;
		}
	}

	/*商品*/
	.m-shop{
		li{
			float: left;
			margin-right: 20px;
			width: 224px;
			height: 407px;
			margin-bottom: 20px;
		}
		li:nth-child(5n){
			margin-right: 0;
		}
		img{
			width: 222px;
			height: 238px;
			border: 1px solid #ddd;
			margin-bottom: 10px;
		}
		p{
			margin-bottom: 7px;
			em{
				color: #fe3000;
			}
		}
		p:nth-of-type(1){
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
		}
		p:nth-of-type(2){
			color: #999;
		}

		p:nth-of-type(4){
			color: #999;
		}
		input{
			font-size: 15px;
		}
		ins{
			display: inline-block;
			width: 32px;
			height: 32px;
			background: url("./assets/images/cart.png") no-repeat;
			float: right;
			margin-right: 10px;
			cursor: pointer;
			margin-top: 13px;
		}
		.el-input__inner{
			border: none;
		}
		.el-input-number__decrease, .el-input-number__increase{
			border: none;
			width: 18px!important;
			height: 18px;
			i{
				vertical-align: 30%;

			}
			.el-icon-minus:before{
				content: '';
			}
			.el-icon-plus:before{
				content: '';
			}
		}

		.el-input-number{
			margin-left: 20px;
			margin-top: 20px;
		}
		.el-input-number .el-input__inner{
			padding: 0;
			width: 60px;
			text-align: center;
			height: 20px;

		}
		.el-input-number--small{
			width: 60px;
		}
		.el-input-number__decrease{
			left: -20px;
			background: url("./assets/images/sum2.png") no-repeat;
			&.is-disabled{
				 background: url("./assets/images/sum4.png") no-repeat;
			}
		}
		.el-input-number__increase{
			right: -20px;
			background: url("./assets/images/sum1.png") no-repeat;
			&.is-disabled{
				 background: url("./assets/images/sum3.png") no-repeat;
			 }
		}
		.u-button{
			background: #fff;
			width: 200px;
			height: 38px;
			border: 1px solid #ccc;
			border-radius: 4px;
			margin-top: 11px;
			cursor: pointer;
		}
		.u-time{
			background: #fe3000;
			border-color:#fe3000 ;
			span{
				vertical-align: -1px;
			}
			em{
				display: inline-block;
				background: url("./assets/images/time.png") no-repeat ;
				padding-left: 25px;
				color: #fff;
			}
		}

	}

	.g-shops{
		.m-shop .el-input-number .el-input__inner{
			background: none;
		}
		width: 1200px;
		margin: 0 auto;
		h2{
			font-size: 20px;
			padding:  20px 0;
			background: url("./assets/images/item3.png") no-repeat 4px 50%;
			padding-left: 46px;
			font-weight: bold;
		}
		.u-new{
			background: url("./assets/images/item4.png") no-repeat 4px 50%;
		}
		.u-ad{
			float: left;
			margin-right: 20px;
			width: 224px;
			height: 407px;
			img{
				width: 100%;
				height: 100%;
			}
		}
		li:nth-of-type(5n){
			margin-right: 20px;
		}
		li:nth-of-type(4){
			margin-right: 0;
		}
		li:nth-of-type(5n+9){
			margin-right: 0;
		}
	}
</style>
