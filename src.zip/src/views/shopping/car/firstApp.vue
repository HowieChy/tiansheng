<template>
<div id="app">

  <!--公用头部组件-->
  <CarHead  :cutTime="cutTime">
    <!--步骤-->
    <div style="float: right" slot='u-search'>
      <img src="./assets/images/first.png" alt="">
    </div>
  </CarHead>

  <div class="g-car">
    <div class="g-content">
      <h2>我的购物车 <ins>剩余时间 :<count-down :endTime="cutTime" :callback="callback" endText="0S"></count-down></ins></h2>
      <div class="m-car">
        <h3>配送说明</h3>
        <table>
          <tr><th><el-checkbox v-model="checked">全选</el-checkbox></th><th>商品名称</th><th>单价</th><th>数量</th><th>小计</th><th>操作</th></tr>
          <tr v-for="(item,index) in cars">
            <td><el-checkbox v-model="item.isCheck" @change="changeCheck"></el-checkbox></td>
            <td><img src="" alt=""><em>{{item.title}}</em></td>
            <td><span>{{ item.price | formatMoney }}</span></td>
            <td> <el-input-number v-model="item.num1" @change="handleChange" :min="1" ></el-input-number></td>
            <td><span>{{ item.price*item.num1 | formatMoney }}</span></td>
            <td><i class="el-icon-close" @click="del(item)"></i></td>
          </tr>
        </table>

        </div>
        <div class="m-all">
          <div class="m-left">
            <a href="">继续购物</a><i>|</i> <p>共<em>{{carList}}</em>件商品，已选择<em>{{carCheck}}</em>件 </p>
          </div>
          <div class="m-right">
            <p>合计（不含运费）： <strong>{{carPrice|formatMoney}}</strong>元 <span>积分：{{carNum}}分</span><a href="javascript:;">去结算</a></p>
          </div>
      </div>

      <div class="g-look">
        <h2><span>最近预览的商品</span></h2>
        <!--商品-->
        <ul class="m-shop clearfix">
          <li v-for="(item,index) in shopItem">
            <a href=""><img :src="item.aImg" alt=""></a>
            <p>{{item.title}}</p>
            <p>库存:{{item.store}}</p>
            <p>会员价：<em>￥{{item.newPrice}}</em></p>
            <p>市场价：￥{{item.oldPrice}}</p>
          </li>
        </ul>
      </div>
    </div>
  </div>

	<!--公用底部组件-->
	<McFoot></McFoot>
</div>
</template>

<script>

import Lib from 'assets/js/Lib';

/*头部组件*/
import CarHead from 'components/CarHead';

/*底部组件*/
import McFoot from 'components/McFoot';

/*倒计时组件*/
import countDown from 'components/Countdown';

/*商品图*/
import aImg from './assets/images/shop.png'

export default {
  data() {

    return {
        //购物车列表
        cars:[{
            isCheck:false,
            aSrc:'',
            aPic:'',
            title:'芒果',
            price:300,
            price2:300,
            num1:1
        },{
            isCheck:false,
            aSrc:'',
            aPic:'',
            title:'芒果',
            price:200,
            price2:200,
            num1:1,
        }],
        checked:false, //是否全选
        carList:2,    //商品总数
        carCheck:0,   //已选择数量
        carPrice:0,   //合计价格
        carNum:0,     //积分

        //倒计时
        cutTime:'1504796400',

        //商品列表
        shopItem:[{
            title:"四川凯特芒果",
            store:10,
            newPrice:'300.00',
            oldPrice:'400.00',
            id:'1',
            numer: 1,
            aImg:aImg,
        },
            {
                title:"四川凯特芒果",
                store:5,
                newPrice:'200.50',
                oldPrice:'300.00',
                id:'5',
                numer: 1,
                aImg:aImg,
            },
            {
                title:"四川凯特芒果",
                store:2,
                newPrice:'700.00',
                id:'2',
                numer: 1,
                aImg:aImg,
            },
            {
                title:"四川凯特芒果",
                store:200,
                newPrice:'500.05',
                oldPrice:'600.00',
                id:'7',
                numer: 1,
                aImg:aImg,
            },
            {
                title:"四川凯特芒果",
                store:200,
                newPrice:'500.05',
                oldPrice:'600.00',
                id:'7',
                numer: 1,
                aImg:aImg,
            }],
	}
  },
    components: {
        CarHead,McFoot,countDown
    },
  //实例初始化最之前，无法获取到data里的数据
  beforeCreate(){
  	
  	
  },  
  //在挂载开始之前被调用
  beforeMount(){
  	
  
  }, 
  //已成功挂载，相当ready()
  mounted(){

  },
  computed:{
    count(){
        return this.price
    }
  },
  filters:{
      //过滤价格
      formatMoney:function (value) {
          return "¥ " + value.toFixed(2) ;
      }
  },
  watch:{
      //全选
      checked:function (val,oldval) {
          if(val==true){
              this.carList=this.cars.length;
              this.carCheck=this.cars.length;
              this.cars.forEach(function (item,index) {
                  item.isCheck=true;
              })
              this.caleTotalPrice();
          }else{
              this.carCheck=0;
              this.carPrice=0;
              this.cars.forEach(function (item,index) {
                  item.isCheck=false;
              })
          }
      },

      carPrice:function (val) {
          this.carNum=parseInt(val/100)
      }
  },
  //相关操作事件
  methods: {

      // 计算选中商品的总价
      caleTotalPrice:function () {
          var _this = this;
          this.carPrice = 0;
          this.cars.forEach(function (item,index) {
              if(item.isCheck){
                  _this.carPrice+=item.num1*item.price;
              }
          });
      },

      //数量变更时计算价格
      handleChange(value) {
          var _this = this;
          this.carPrice = 0;
          this.cars.forEach(function (item,index) {
              if(item.isCheck){
                  _this.carPrice+=value*item.price;
              }
          });

      },

      //选中商品时计算价格
      changeCheck(){
          var _this = this;
          this.caleTotalPrice();
          this.carCheck=0;
          this.cars.forEach(function (item,index) {
              if(item.isCheck){
                  _this.carCheck+=1
              }
          });
      },

      //删除商品
      del(item){
          this.cars.splice(this.cars.indexOf(item),1);
          this.caleTotalPrice();
          this.carList=this.cars.length;
      },

      //开始倒计时
      callback(){
          console.log('结束1')
      },


  }
}
</script>

<style lang="less">
	body{
      background: #f5f5f5;
    }
    .g-content{
      width: 1200px;
      margin: 0 auto;
      margin-bottom: 20px;
      h2{
        margin: 30px 0;
        font-size: 20px;
      }
      ins{
        border: 1px solid #ff3002;
        padding:4px ;
        color: #ff3002;
        margin-left: 20px;
        font-size: 14px;
        vertical-align: middle;
      }
      h3{
        background: url("./assets/images/table.png") no-repeat;
        margin-bottom: 30px;
        padding-left: 50px;
        color: #999;
      }
    }
    .m-car{
      padding: 30px 40px;
      background: #fff;
    }
    table{
      border-top: 1px solid #ddd;
      width: 100%;
      th{
        padding: 20px 0;
        text-align: center;
      }
      th:nth-of-type(1){
        width: 70px;
        text-align: right;
        .el-checkbox__input{
          margin-right: 6px;
        }

      }
      th:nth-of-type(2){
        width: 450px;
        text-align: left;
        text-indent: 160px;
      }
      th:nth-of-type(3){
        width: 120px;
      }
    th:nth-of-type(4){
      width: 220px;
    }
    th:nth-of-type(5){
      width: 130px;
    }
      td{
        padding: 28px 0;
        border-top: 1px solid #ddd;
        text-align: center;
        position: relative;
        span{
          color: #ff3002;
          font-size: 16px;
        }
        i{
          font-size: 10px;
          cursor: pointer;
        }
        img{
          width: 136px;
          height: 136px;
          border: 1px solid #ddd;
          float: left;
        }
        em{
          font-size: 16px;
          width: 250px;
          display: inline-block;
          position: absolute;
          left: 158px;
          top: 50%;
          transform: translateY(-50%);
          text-align: left;
        }
        .el-checkbox__input{
          margin-left: 20px;
        }
      }
      td:first-child{
        text-align: left;
        .el-checkbox__input{
          margin-left: 12px;
        }
      }
      .el-input-number__decrease{
        left: -37px;
        top: 0;
      }
      .el-input-number__increase{
        right: -37px;
        top: 0;
      }
      .el-input-number__decrease, .el-input-number__increase{
        border: 1px solid #bfcbd9;
        background: #ededed;
      }
      input{
        border: 1px solid #000;
        text-align: center;
      }
      .el-input-number .el-input__inner{
        padding: 0;
        width: 60px;
        border-radius: 0;
      }
      .el-input-number{
        width: 60px;
      }
      .el-checkbox__input.is-checked .el-checkbox__inner{
        border-color: #33ba44;
        background: #33ba44;
        border-radius: 0;
      }
      .el-checkbox__inner{
        border-radius: 0;
      }
    }
    .m-all{
      height: 53px;
      line-height: 53px;
      background: #fff;
      margin: 30px 0;
      .m-left{
        float: left;
        color: #999;
        p{
          display: inline-block;
        }
        a{
          display: inline-block;
          padding:0 30px;
          color: #999;
        }
        i{
          margin-right: 30px;
          font-style: normal;
        }
        em{
          color: #33ba44;
          font-weight: bold;
          margin: 0 2px;
        }
      }
      .m-right{
        float: right;
        p{
          color: #ff3002;
        }
        strong{
          font-size: 18px;
        }
        span{
          margin:0 20px ;
        }
        a{
          color: #fff;
          display: inline-block;
          text-align: center;
          font-size: 18px;
          width: 210px;
          background: #33ba44;

        }
      }
    }


    /*最近预览商品*/
    .g-look{
      h2{
        margin-top:60px ;
        position: relative;
        height: 1px;
        background: #ccc;
        span{
          position: absolute;
          font-size: 22px;
          color: #999;
          width: 300px;
          height:50px ;
          line-height: 50px;
          background: #f5f5f5;
          text-align: center;
          left: 50%;
          top: 50%;
          transform: translate(-50%,-50%);
        }
      }
    }
    .m-shop{
      li{
        float: left;
        margin-right: 20px;
        width: 224px;
        height: 370px;
        margin-bottom: 20px;
      }
      li:nth-child(5n){
        margin-right: 0;
      }
      img{
        width: 222px;
        height: 238px;
        border: 1px solid #ddd;
        margin-bottom: 10px;
      }
      p{
        margin-bottom: 7px;
      em{
        color: #fe3000;
      }
      }
      p:nth-of-type(1){
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      p:nth-of-type(2){
        color: #999;
      }

      p:nth-of-type(4){
        color: #999;
      }

    }


    .g-float{
      display: none;
    }
    .g-cart{
      display: none;
    }
</style>
