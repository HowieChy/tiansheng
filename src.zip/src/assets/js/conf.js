
import store from 'store';

var Rxports = {
	appname:"云收银",
	url_host:window.location.host,
	background:'#FBF9FE', 
}

export default Rxports;




















































